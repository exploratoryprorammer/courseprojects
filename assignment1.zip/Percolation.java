/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private boolean[][] grid;
    private int n;
    private WeightedQuickUnionUF unionUF;
    private final int top;
    private final int bottom;
    private int opensites;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("Invalid grid size");
        }
        else {
            this.n = n;
            this.grid = new boolean[n][n];
            unionUF = new WeightedQuickUnionUF(n * n + 2);
            top = n * n;
            bottom = n * n + 1;
            opensites = 0;

        }
    }

    private int indexfinder(int row, int col) {
        return row * n + col;
    }

    private void connect(int row, int col) {
        if (col + 1 <= n - 1 && isOpen(row + 1, col + 2)) {
            unionUF.union(indexfinder(row, col), indexfinder(row, col + 1));
        }
        if (col - 1 >= 0 && isOpen(row + 1, col)) {
            unionUF.union(indexfinder(row, col), indexfinder(row, col - 1));
        }
        if (row + 1 <= n - 1 && isOpen(row + 2, col + 1)) {
            unionUF.union(indexfinder(row, col), indexfinder(row + 1, col));
        }
        if (row - 1 >= 0 && isOpen(row, col + 1)) {
            unionUF.union(indexfinder(row, col), indexfinder(row - 1, col));
        }
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row > n || row < 1 || col > n || col < 1) {
            throw new IllegalArgumentException("Out of bound");
        }
        else {
            if (!isOpen(row, col)) {
                grid[row - 1][col - 1] = true;
                if (row - 1 == 0) {
                    unionUF.union(indexfinder(0, col - 1), top);
                }
                if (row - 1 == n - 1) {
                    unionUF.union(indexfinder(row - 1, col - 1), bottom);
                }
                connect(row - 1, col - 1);
                opensites += 1;
            }
        }

    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row > n || row < 1 || col > n || col < 1) {
            throw new IllegalArgumentException("Out of bound");
        }
        else {
            return grid[row - 1][col - 1];
        }

    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row > n || row < 1 || col > n || col < 1) {
            throw new IllegalArgumentException("Out of bound");
        }
        else {
            return unionUF.find(indexfinder(row - 1, col - 1)) == unionUF.find(top);
        }
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return opensites;
    }

    // does the system percolate?
    public boolean percolates() {
        return unionUF.find(top) == unionUF.find(bottom);
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation p = new Percolation(3);
        System.out.println(p.percolates());
        p.open(1, 1);
        System.out.println(p.percolates());
        p.open(2, 1);
        p.open(3, 1);

        System.out.println(p.percolates());
        p.open(3, 1);
        System.out.println(p.percolates());
        System.out.println(p.numberOfOpenSites());

    }
}
