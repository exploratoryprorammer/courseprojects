/* *****************************************************************************
 *  Name:              Alan Turing
 *  Coursera User ID:  123456
 *  Last modified:     1/1/2019
 **************************************************************************** */


import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
    private static final double CONFIDENCE_95 = 1.96;
    private int n;
    private int trials;
    private Percolation p;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        this.n = n;
        this.p = new Percolation(n);
        this.trials = trials;
    }

    private double perform() {
        p = new Percolation(n);
        double count = 0;
        int x;
        int y;
        while (!p.percolates()) {
            x = StdRandom.uniformInt(1, n + 1);
            y = StdRandom.uniformInt(1, n + 1);
            if (!p.isOpen(x, y)) {
                p.open(x, y);
                count += 1.0;
            }

        }
        return count / (n * n);
    }

    // sample mean of percolation threshold
    public double mean() {
        double[] total = new double[trials];
        for (int i = 0; i < trials; i++) {
            total[i] = perform();
        }
        return StdStats.mean(total);
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        double[] stdsqrdnum = new double[trials];
        for (int i = 0; i < trials; i++) {
            stdsqrdnum[i] = perform();
        }
        return StdStats.stddev(stdsqrdnum);
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - ((CONFIDENCE_95 * stddev()) / (Math.sqrt(trials)));
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + ((CONFIDENCE_95 * stddev()) / (Math.sqrt(trials)));
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats stats = new PercolationStats(n, t);
        String conf = Double.toString(stats.confidenceLo()) + ", " + Double.toString(
                stats.confidenceHi());
        System.out.println("mean                        = " + stats.mean());
        System.out.println("Standard Deviation          = " + stats.stddev());
        System.out.println("Confidence                  = " + conf);


    }

}
